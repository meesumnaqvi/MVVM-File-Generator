//  ___FILEHEADER___

protocol ___FILEBASENAMEASIDENTIFIER___Protocol {
    func fetchData() async throws -> BaseDataResponse<EmptyResponseModel>?
}

class ___FILEBASENAMEASIDENTIFIER___: ___FILEBASENAMEASIDENTIFIER___Protocol {
    
    /// Change Base Response in case of List Response (i.e: BaseListResponse)
    /// Change api request type to public in case of calling api's which diesn't required access token(
    /// Change Reponse return type
    ///  in case of
    /// - Returns: YourResponseObject
    func fetchData() async throws -> BaseDataResponse<EmptyResponseModel>? {
        guard let url = URLHelper.generateURL(baseEndpoint: AppConfig.BASE_URL, withPath: APIEndpoints.<#endpoint#>, queryParams: nil) else {
            throw AppError.otherError("Invlid URL")
        }
        let headers = UserPreferences.shared.get(forKey: UserPreferences.Keys.apiHeadersKey, as: APIHeaders.self)?.dictionary ?? [:]
        
        let response: BaseDataResponse<EmptyResponseModel> = try await NetworkManager.shared.privateApiRequest(url, method: .get, headers: headers)
        return response
    }
}
