//  ___FILEHEADER___

import SwiftUI
import Combine

struct ___FILEBASENAMEASIDENTIFIER___: View {
    @State var cancellable = Set<AnyCancellable>()
    @EnvironmentObject var navigationManager: NavigationManager
    var viewModel: ___FILEBASENAMEASIDENTIFIER___ModelProtocol
    
    init(viewModel: ___FILEBASENAMEASIDENTIFIER___ModelProtocol) {
        self.viewModel = viewModel
    }
    
    var body: some View {
            ZStack {
                VStack(alignment: .center, spacing: 20, content: {
                    // Contains Navigation bar with back button and Title
                    Header(titleText: AppStrings.title, hasBackButton: true, onBackArrowClick: {
                        // Back Button Action
                        navigationManager.goBack()
                    }, hasRightBarButtonItem: false,
                           rightBarButtonItemText: "", rightBarButtonItemAction: {
                        // do right bar button action here
                    }, titleAlignment: .leading, subTitle: "", titleImageURL: "")
                    
                    ScrollView {
                        
                        VStack(alignment: .center, spacing: 20, content: {
                            // do you coding here
                            Text("Do your coding here")
                            Spacer()
                            
                            Button("Your Button") {
                                navigationManager.navigate(to: .forgotPassword)
                            }
                            .foregroundColor(.blueText)
                            .font(.interRegular16)
                            Spacer()
                        })
                    }
                    .scrollBounceBehavior(.basedOnSize, axes: .vertical)
                    .scrollIndicators(.hidden)
                })
                .padding()
            }
            .background(LinearGradient.screenBg)
            .onAppear {
                AnalyticsManager.logScreenView(screenName: String(describing: Self.self))
                // take input for request from text fields
                self.viewModel.fetchData()
                
                setUpBinding()
            }.genericAlert()
    }
}

#Preview {
    ___FILEBASENAMEASIDENTIFIER___(viewModel: ___FILEBASENAME___Model(repository: <#YourRepository#>))
}

extension ___FILEBASENAMEASIDENTIFIER___ {
    
    private func setUpBinding() {
        viewModel.dataSubject.receive(on: DispatchQueue.main).sink { data in
            // set up data in view
        }.store(in: &cancellable)
        
        viewModel.errorSubject.receive(on: DispatchQueue.main).sink { error in
            // handle error here
            print("Error: \(error ?? "")")
            AlertManager.shared.showAlert(title: AppStrings.Error, message: error ?? "")
        }.store(in: &cancellable)
        
        viewModel.showHUD.receive(on: DispatchQueue.main).sink { shoudShow in
            // show Hud here
            showHUD(shoudShow)
        }.store(in: &cancellable)
    }
}


