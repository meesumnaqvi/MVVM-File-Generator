//  ___FILEHEADER___

import Foundation
import Combine

protocol ___FILEBASENAMEASIDENTIFIER___Protocol {
    var dataSubject: CurrentValueSubject<EmptyResponseModel?, Never> { get }
    var errorSubject: PassthroughSubject<String?, Never> { get }
    var showHUD: PassthroughSubject<Bool?, Never> { get }
    
    func fetchData()
}

class ___FILEBASENAMEASIDENTIFIER___: ___FILEBASENAMEASIDENTIFIER___Protocol {
    
    let dataSubject = CurrentValueSubject<EmptyResponseModel?, Never>(nil)
    let errorSubject = PassthroughSubject<String?, Never>()
    var showHUD = PassthroughSubject<Bool?, Never>()
    private let repository: <#YourRepositoryProtocol#>
    var networkManager: NetworkManager
    
    init(repository: <#YourRepository#>) {
        self.repository = repository
        self.networkManager = NetworkManager.shared
    }
    
    
    // call api in this
    func fetchData() {
        Task {
            showHUD.send(true)
            do {
                guard let response = try await repository.fetchData() else { return }
                showHUD.send(false)
                if response.statusCode != 200 {
                    errorSubject.send(response.message)
                    print(">>>>>Error occured:<<<<<< \(response.message)")
                } else {
                    dataSubject.send(response.data)
                    print("<<<<<<Response Model:>>>>>> \(response.data)")
                }
            } catch let err {
                showHUD.send(false)
                errorSubject.send(err.localizedDescription)
                print(">>>>>Error occured:<<<<<< \(err.localizedDescription)")
            }
        }
    }
    
    
    
}
