//  ___FILEHEADER___

import Foundation

class ___FILEBASENAMEASIDENTIFIER___: Codable {
    var template: String?
    var data: String?
    
    enum CodingKeys: String, CodingKey {
        case template
        case data
    }
    
    required init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        template = try container.decodeIfPresent(String.self, forKey: .template)
        data = try container.decodeIfPresent(String.self, forKey: .data)
    }
    
}
