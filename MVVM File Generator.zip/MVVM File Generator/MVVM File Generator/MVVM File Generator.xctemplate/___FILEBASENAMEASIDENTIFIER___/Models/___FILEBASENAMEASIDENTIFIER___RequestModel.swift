//  ___FILEHEADER___

import Foundation

struct ___FILEBASENAMEASIDENTIFIER___: ModelToDictionaryProtocol {
    var email: String
    var password: String
    
    enum CodingKeys: String, CodingKey {
        case email
        case password
    }
}
